# CameraMove — Fabric 1.21.11

Client-side camera turning mod for Minecraft Java 1.21.11 / Fabric. Eight separately configurable hold-to-turn keybinds: left, right, up, down and four diagonals. Releasing the key stops rotation. Diagonal movement is normalized.

## Settings
- Press **O** in-game to open CameraMove settings (the key can be reassigned in Options → Controls → Key Binds → CameraMove).
- **Camera speed:** 0.1–12 degrees per tick.
- **Diagonal angle:** 15–75 degrees, default 45 degrees.
- Press **Save and close** to store settings in `config/cameramove.properties`.
- Key assignments are configured in Options → Controls → Key Binds → CameraMove.

## Build the JAR from an Android phone (GitHub Actions)
1. Create a GitHub repository.
2. Upload the contents of this folder, including `.github/workflows/build.yml`.
3. Open the repository's **Actions** tab.
4. Select **Build CameraMove JAR** → **Run workflow**.
5. Download the artifact named **CameraMove-Fabric-1.21.11** from the completed run and extract the JAR.

## Install in MojoLauncher
Put the JAR in the instance's `mods` folder. The instance must use Minecraft Java 1.21.11, Fabric Loader, and Fabric API 0.141.1+1.21.11. Restart the game.

**Android note:** This is a keyboard-keybind mod. MojoLauncher must send its on-screen key buttons as keyboard key presses for them to trigger. It does not create independent touch-screen buttons itself.

package com.example.cameramove;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class CameraMoveClient implements ClientModInitializer {
    private static final float PITCH_LIMIT = 89.0f;
    private static final float DEFAULT_SPEED = 2.4f;
    private static final float DEFAULT_DIAGONAL_ANGLE = 45.0f;
    private static float speed = DEFAULT_SPEED; // degrees per tick
    private static float diagonalAngle = DEFAULT_DIAGONAL_ANGLE;
    private static Path configPath;

    private static KeyBinding left, right, up, down;
    private static KeyBinding upLeft, upRight, downLeft, downRight, openSettings;

    private static KeyBinding bind(String name, int key, KeyBinding.Category category) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.cameramove." + name, InputUtil.Type.KEYSYM, key, category));
    }

    public static float getSpeed() { return speed; }
    public static float getDiagonalAngle() { return diagonalAngle; }
    public static void setSpeed(float value) { speed = Math.max(0.1f, Math.min(12.0f, value)); }
    public static void setDiagonalAngle(float value) { diagonalAngle = Math.max(15.0f, Math.min(75.0f, value)); }

    public static void saveConfig() {
        if (configPath == null) return;
        Properties p = new Properties();
        p.setProperty("speed", Float.toString(speed));
        p.setProperty("diagonalAngle", Float.toString(diagonalAngle));
        try {
            Files.createDirectories(configPath.getParent());
            try (OutputStream out = Files.newOutputStream(configPath)) {
                p.store(out, "CameraMove settings");
            }
        } catch (IOException e) {
            System.err.println("[CameraMove] Could not save settings: " + e.getMessage());
        }
    }

    private static void loadConfig(MinecraftClient client) {
        configPath = client.runDirectory.toPath().resolve("config/cameramove.properties");
        if (!Files.exists(configPath)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(configPath)) {
            p.load(in);
            setSpeed(Float.parseFloat(p.getProperty("speed", Float.toString(DEFAULT_SPEED))));
            setDiagonalAngle(Float.parseFloat(p.getProperty("diagonalAngle", Float.toString(DEFAULT_DIAGONAL_ANGLE))));
        } catch (Exception e) {
            speed = DEFAULT_SPEED;
            diagonalAngle = DEFAULT_DIAGONAL_ANGLE;
            System.err.println("[CameraMove] Could not load settings: " + e.getMessage());
        }
    }

    @Override
    public void onInitializeClient() {
        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("cameramove", "controls"));
        left = bind("left", GLFW.GLFW_KEY_UNKNOWN, category);
        right = bind("right", GLFW.GLFW_KEY_UNKNOWN, category);
        up = bind("up", GLFW.GLFW_KEY_UNKNOWN, category);
        down = bind("down", GLFW.GLFW_KEY_UNKNOWN, category);
        upLeft = bind("up_left", GLFW.GLFW_KEY_UNKNOWN, category);
        upRight = bind("up_right", GLFW.GLFW_KEY_UNKNOWN, category);
        downLeft = bind("down_left", GLFW.GLFW_KEY_UNKNOWN, category);
        downRight = bind("down_right", GLFW.GLFW_KEY_UNKNOWN, category);
        openSettings = bind("open_settings", GLFW.GLFW_KEY_O, category);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            loadConfigOnce(client);
            while (openSettings.wasPressed()) {
                Screen parent = client.currentScreen;
                client.setScreen(new CameraMoveConfigScreen(parent));
            }
            if (client.currentScreen != null) return;

            float x = 0.0f, y = 0.0f;
            if (left.isPressed()) x -= 1.0f;
            if (right.isPressed()) x += 1.0f;
            if (up.isPressed()) y += 1.0f;
            if (down.isPressed()) y -= 1.0f;
            double radians = Math.toRadians(diagonalAngle);
            float dx = (float) Math.cos(radians), dy = (float) Math.sin(radians);
            if (upLeft.isPressed()) { x -= dx; y += dy; }
            if (upRight.isPressed()) { x += dx; y += dy; }
            if (downLeft.isPressed()) { x -= dx; y -= dy; }
            if (downRight.isPressed()) { x += dx; y -= dy; }

            if (x == 0.0f && y == 0.0f) return;
            float length = (float) Math.sqrt(x * x + y * y);
            x /= length;
            y /= length;
            client.player.setYaw(client.player.getYaw() + x * speed);
            float newPitch = client.player.getPitch() - y * speed;
            client.player.setPitch(Math.max(-PITCH_LIMIT, Math.min(PITCH_LIMIT, newPitch)));
        });
    }

    private static boolean configLoaded = false;
    private static void loadConfigOnce(MinecraftClient client) {
        if (!configLoaded) { loadConfig(client); configLoaded = true; }
    }
}

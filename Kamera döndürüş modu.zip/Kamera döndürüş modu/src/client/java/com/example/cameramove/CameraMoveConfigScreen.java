package com.example.cameramove;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public class CameraMoveConfigScreen extends Screen {
    private final Screen parent;
    private SliderWidget speedSlider;
    private SliderWidget angleSlider;

    public CameraMoveConfigScreen(Screen parent) {
        super(Text.literal("CameraMove Ayarları"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int center = this.width / 2;
        int sliderWidth = Math.min(300, this.width - 40);
        int left = center - sliderWidth / 2;

        speedSlider = new SliderWidget(left, this.height / 2 - 42, sliderWidth, 20,
                Text.empty(), (CameraMoveClient.getSpeed() - 0.1) / 11.9) {
            private float speed() { return 0.1f + (float) (this.value * 11.9); }
            @Override protected void updateMessage() {
                this.setMessage(Text.literal("Kamera hızı: " + String.format(java.util.Locale.ROOT, "%.1f", speed()) + "°/tik"));
            }
            @Override protected void applyValue() { CameraMoveClient.setSpeed(speed()); }
        };
        angleSlider = new SliderWidget(left, this.height / 2 - 10, sliderWidth, 20,
                Text.empty(), (CameraMoveClient.getDiagonalAngle() - 15.0) / 60.0) {
            private float angle() { return 15.0f + (float) (this.value * 60.0); }
            @Override protected void updateMessage() {
                this.setMessage(Text.literal("Çapraz açı: " + Math.round(angle()) + "°"));
            }
            @Override protected void applyValue() { CameraMoveClient.setDiagonalAngle(angle()); }
        };
        addDrawableChild(speedSlider);
        addDrawableChild(angleSlider);
        addDrawableChild(ButtonWidget.builder(Text.literal("Kaydet ve kapat"), button -> {
            CameraMoveClient.saveConfig();
            close();
        }).dimensions(center - 100, this.height / 2 + 28, 200, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Varsayılana dön"), button -> {
            CameraMoveClient.setSpeed(2.4f);
            CameraMoveClient.setDiagonalAngle(45.0f);
            CameraMoveClient.saveConfig();
            close();
        }).dimensions(center - 100, this.height / 2 + 54, 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 90, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Tuşları: Seçenekler > Kontroller > Tuş Atamaları > CameraMove"),
                width / 2, height / 2 + 88, 0xCCCCCC);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Ayar ekranını açma tuşu: O (Kontrollerden değiştirilebilir)"),
                width / 2, height / 2 + 101, 0xAAAAAA);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public void close() { if (client != null) client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}
